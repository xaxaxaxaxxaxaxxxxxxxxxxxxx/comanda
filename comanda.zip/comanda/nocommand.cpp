#include "nocommand.h"

NoCommand::NoCommand()
{

}

void NoCommand::execute() {

}
